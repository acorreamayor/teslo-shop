export class CreateToolGroupDto {}
