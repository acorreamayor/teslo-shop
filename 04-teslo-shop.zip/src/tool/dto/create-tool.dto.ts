export class CreateToolDto {}
