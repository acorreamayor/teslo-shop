export class CreateParameterUserOrganizationDto {}
