export class ParameterUserOrganization {}
