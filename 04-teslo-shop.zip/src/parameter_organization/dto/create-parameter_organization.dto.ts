export class CreateParameterOrganizationDto {}
