export class ParameterOrganization {}
