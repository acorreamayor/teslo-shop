export class CreateParameterUserDto {}
