

export interface JwtPayload {
    id: string;
    

    // todo: añadir todo lo que quieran grabar.
}