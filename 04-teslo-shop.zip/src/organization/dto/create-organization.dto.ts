export class CreateOrganizationDto {}
