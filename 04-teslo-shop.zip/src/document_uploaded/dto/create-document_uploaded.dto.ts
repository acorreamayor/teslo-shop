export class CreateDocumentUploadedDto {}
