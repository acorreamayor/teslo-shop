export class CreateParameterToolDto {}
