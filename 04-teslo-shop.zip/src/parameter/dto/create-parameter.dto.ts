export class CreateParameterDto {}
